import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IptvService } from '../../services/iptv-service';
import { Channel } from '../../models/channel';

@Component({
  selector: 'app-live-tv',
  templateUrl: './live-tv.html',
  styleUrl: './live-tv.scss',
  standalone: true,
  imports: [CommonModule]
})

export class LiveTvComponent implements OnInit {


  constructor(private iptv: IptvService, private cdr: ChangeDetectorRef) { }

  allChannels: Channel[] = [];

  ngOnInit(): void {

  }



}
